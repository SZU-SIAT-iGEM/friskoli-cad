"""Friskoli-CAD shared code."""
