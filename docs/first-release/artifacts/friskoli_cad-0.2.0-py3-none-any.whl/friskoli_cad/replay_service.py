"""Small local HTTP service for protocol-based simulation replay."""

from __future__ import annotations

import argparse
import base64
import binascii
import json
import math
import hashlib
import os
import re
import socket
from copy import deepcopy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib.resources import files
from pathlib import Path
from typing import Mapping
from urllib.parse import parse_qs, urlsplit

from friskoli_cad.engine import SimulationError
from friskoli_cad.engine.science_extensions import modular_registry
from friskoli_cad.engine.profiles import MODULAR_PROFILE, registry_for_profile, registry_for_project
from friskoli_cad.project import simulation_from_project
from friskoli_cad.project import validate_project
from friskoli_cad.protocol import ProtocolError, validate_frame_sequence
from friskoli_cad.protocol.task_validation import TaskValidationError, strict_json_loads
from friskoli_cad.tasks import TaskError, TaskLimits, TaskService


EXAMPLE_PROJECT = files("friskoli_cad").joinpath("examples", "modular_foundation.project.json")
MAX_REQUEST_BYTES = 1_000_000
MAX_STEPS = 10_000
MAX_REPLAY_VALUES = 1_000_000
MAX_VIEW_TILES = 4_096
MAX_VIEW_CELLS = 2_000
MAX_REPLAY_CELL_FRAMES = MAX_VIEW_CELLS * 101
MAX_REPLAY_BYTES = 128 * 1024 * 1024
MAX_DESIGN_REQUEST_BYTES = 64 * 1024 * 1024
STATIC_FILES = {
    "/service-worker.js": ("service-worker.js", "application/javascript; charset=utf-8"),
    **{f"/{name}.mjs": (f"{name}.mjs", "text/javascript; charset=utf-8") for name in ("commands", "transaction-dialog", "workspace-transactions", "workspace-session", "result-analysis", "resolution-guidance", "paged-replay", "package-panel")},
    "/design-panel.mjs": ("design-panel.mjs", "text/javascript; charset=utf-8"),
    "/metrics.mjs": ("metrics.mjs", "text/javascript; charset=utf-8"),
    "/metric-results.mjs": ("metric-results.mjs", "text/javascript; charset=utf-8"),
    "/templates.mjs": ("templates.mjs", "text/javascript; charset=utf-8"),
    "/registry.css": ("registry.css", "text/css; charset=utf-8"),
    "/migration.mjs": ("migration.mjs", "text/javascript; charset=utf-8"),
    "/math-inspector.mjs": ("math-inspector.mjs", "text/javascript; charset=utf-8"),
    "/vendor/katex/katex.mjs": ("vendor/katex/katex.mjs", "text/javascript; charset=utf-8"),
    "/vendor/katex/katex.min.css": ("vendor/katex/katex.min.css", "text/css; charset=utf-8"),
    "/panels.mjs": ("panels.mjs", "text/javascript; charset=utf-8"),
    "/menus.mjs": ("menus.mjs", "text/javascript; charset=utf-8"),
    "/workflow-layout.mjs": ("workflow-layout.mjs", "text/javascript; charset=utf-8"),
    "/assembly-library.mjs": ("assembly-library.mjs", "text/javascript; charset=utf-8"),
    "/field-slice.mjs": ("field-slice.mjs", "text/javascript; charset=utf-8"),
    "/results.mjs": ("results.mjs", "text/javascript; charset=utf-8"),
    "/workspace.mjs": ("workspace.mjs", "text/javascript; charset=utf-8"),
    "/kernel-client.mjs": ("kernel-client.mjs", "text/javascript; charset=utf-8"),
    "/task-store.mjs": ("task-store.mjs", "text/javascript; charset=utf-8"),
    "/task-persistence.mjs": ("task-persistence.mjs", "text/javascript; charset=utf-8"),
    "/ui-guidance.mjs": ("ui-guidance.mjs", "text/javascript; charset=utf-8"),
    "/": ("index.html", "text/html; charset=utf-8"),
    "/style.css": ("style.css", "text/css; charset=utf-8"),
    "/app.mjs": ("app.mjs", "text/javascript; charset=utf-8"),
    "/replay.mjs": ("replay.mjs", "text/javascript; charset=utf-8"),
    "/i18n.mjs": ("i18n.mjs", "text/javascript; charset=utf-8"),
    "/scene3d.mjs": ("scene3d.mjs", "text/javascript; charset=utf-8"),
    "/catalog.mjs": ("catalog.mjs", "text/javascript; charset=utf-8"),
    "/population.mjs": ("population.mjs", "text/javascript; charset=utf-8"),
    "/workflow.mjs": ("workflow.mjs", "text/javascript; charset=utf-8"),
    "/workflow-components.mjs": ("workflow-components.mjs", "text/javascript; charset=utf-8"),
    "/graph-edit.mjs": ("graph-edit.mjs", "text/javascript; charset=utf-8"),
    "/placeables.mjs": ("placeables.mjs", "text/javascript; charset=utf-8"),
    "/icons.mjs": ("icons.mjs", "text/javascript; charset=utf-8"),
    "/vendor/three/build/three.module.js": ("vendor/three/build/three.module.js", "text/javascript; charset=utf-8"),
    "/vendor/three/build/three.core.js": ("vendor/three/build/three.core.js", "text/javascript; charset=utf-8"),
    "/vendor/three/examples/jsm/controls/OrbitControls.js": ("vendor/three/examples/jsm/controls/OrbitControls.js", "text/javascript; charset=utf-8"),
    "/vendor/three/examples/jsm/controls/TransformControls.js": ("vendor/three/examples/jsm/controls/TransformControls.js", "text/javascript; charset=utf-8"),
    "/assets/friskoli.svg": ("assets/friskoli.svg", "image/svg+xml"),
    "/assets/cad.svg": ("assets/cad.svg", "image/svg+xml"),
}


for _font in files("friskoli_cad").joinpath("web", "vendor", "katex", "fonts").iterdir():
    _extension = _font.name.rsplit(".", 1)[-1]
    if _font.is_file() and _extension in ("woff2", "woff", "ttf"):
        STATIC_FILES[f"/vendor/katex/fonts/{_font.name}"] = (
            f"vendor/katex/fonts/{_font.name}", f"font/{_extension}")


class ReplayRequestError(ValueError):
    def __init__(self, code: str, message: str, status: int = 400):
        self.code = code
        self.status = status
        super().__init__(message)


def _snapshot_payload(snapshot, *, spatial=False) -> dict:
    return {
        "frame": snapshot.cell_frame,
        **({'metrics': dict(snapshot.metrics)} if snapshot.metrics else {}),
        **({'lifecycle_details': dict(snapshot.lifecycle_details)} if snapshot.lifecycle_details else {}),
        **({"object_states": {key: dict(value) for key, value in snapshot.object_states.items()}} if spatial else {}),
        "concentrations": {
            species: {"unit": snapshot.concentration_units[species], "values_zyx": values.tolist()}
            for species, values in snapshot.concentration_fields.items()
        },
    }


def prepare_project(project: Mapping[str, object], *, dt_s: float, steps: int, validation_only=False):
    """Validate and limit allocations before creating the initial state; never advances time."""
    maximum_steps = MAX_STEPS
    if type(steps) is not int or not 1 <= steps <= maximum_steps:
        raise ReplayRequestError("replay.steps", f"steps must be an integer from 1 to {maximum_steps}")
    if type(dt_s) not in (int, float) or not math.isfinite(dt_s) or dt_s <= 0:
        raise ReplayRequestError("replay.dt", "dt_s must be positive and finite")
    if not math.isfinite(dt_s * steps):
        raise ReplayRequestError("replay.duration", "total duration must be finite")
    registry = registry_for_project(project)
    validate_project(project, registry.manifests, registry=registry)
    nx, ny, nz = project["domain"]["counts_xyz"]
    allocated_frames = 1 if validation_only else steps + 1
    if nx * ny > MAX_VIEW_TILES or nx * ny * nz * allocated_frames > MAX_REPLAY_VALUES:
        raise ReplayRequestError("replay.size", "grid exceeds the local viewer limit", 413)
    cells = sum(len(group["ids"]) for group in project["groups"].values())
    if cells > MAX_VIEW_CELLS:
        raise ReplayRequestError("replay.cell_count", "cell count exceeds the local viewer limit", 413)
    if cells * allocated_frames > MAX_REPLAY_CELL_FRAMES:
        raise ReplayRequestError("replay.cell_frames", "estimated cumulative cell frames exceed the synchronous replay limit", 413)
    if project.get("execution_profile") == MODULAR_PROFILE and nx * ny * nz * max(1, len(project["species"])) * allocated_frames > MAX_REPLAY_VALUES:
        raise ReplayRequestError("replay.size", "replay field data exceeds the local viewer limit", 413)
    simulation = simulation_from_project(project, registry)
    initial = simulation.current
    field_count = max(1, len(initial.concentration_fields))
    if initial.domain.nx * initial.domain.ny > MAX_VIEW_TILES:
        raise ReplayRequestError("replay.view_size", "XY slice exceeds the local viewer limit", 413)
    if len(initial.cell_frame["cells"]) > MAX_VIEW_CELLS:
        raise ReplayRequestError("replay.cell_count", "cell count exceeds the local viewer limit", 413)
    if initial.domain.voxel_count * field_count * allocated_frames > MAX_REPLAY_VALUES:
        raise ReplayRequestError("replay.size", "replay field data exceeds the local viewer limit", 413)
    if not validation_only:
        spatial = project.get("execution_profile") == MODULAR_PROFILE
        # Admission estimate only: changing geometry, events and numeric values are
        # measured again for every emitted frame below.
        estimate = _json_size(_replay_envelope(project)) + 1024
        estimate += (_json_size(_snapshot_payload(initial, spatial=spatial)) + 2) * allocated_frames
        if estimate > MAX_REPLAY_BYTES:
            raise ReplayRequestError("replay.bytes", "estimated result bytes exceed the synchronous replay limit", 413)
    return simulation


def _json_size(value) -> int:
    return sum(len(part.encode("utf-8")) for part in json.JSONEncoder(
        ensure_ascii=False, allow_nan=False).iterencode(value))


def _replay_envelope(project) -> dict:
    return {"replay_format_version": "0.1.0", "project_id": project["id"],
            "run": project["run"], "domain": project["domain"], "snapshots": []}


def build_replay(project: Mapping[str, object], *, dt_s: float, steps: int) -> dict:
    """Run an immutable project and expose existing frames without changing their schema."""
    project = deepcopy(project)
    simulation = prepare_project(project, dt_s=dt_s, steps=steps)
    initial = simulation.current
    spatial = project.get("execution_profile") == MODULAR_PROFILE
    replay = _replay_envelope(project)
    snapshots = replay["snapshots"]
    # Reserve space for the HTTP execution metadata appended by ReplayHandler.
    result_bytes = _json_size(replay) + 1024
    cell_frames = 0
    for index in range(steps + 1):
        snapshot = initial if index == 0 else simulation.step(dt_s)
        cells = len(snapshot.cell_frame["cells"])
        if cells > MAX_VIEW_CELLS:
            raise ReplayRequestError("replay.cell_count", "cell count exceeds the local viewer limit", 413)
        cell_frames += cells
        if cell_frames > MAX_REPLAY_CELL_FRAMES:
            raise ReplayRequestError("replay.cell_frames", "cumulative cell frames exceed the synchronous replay limit", 413)
        payload = _snapshot_payload(snapshot, spatial=spatial)
        result_bytes += _json_size(payload) + (2 if snapshots else 0)
        if result_bytes > MAX_REPLAY_BYTES:
            raise ReplayRequestError("replay.bytes", "result bytes exceed the synchronous replay limit", 413)
        snapshots.append(payload)
    validate_frame_sequence((item["frame"] for item in snapshots), project["run"])
    return replay


class ReplayHandler(BaseHTTPRequestHandler):
    def _send(self, status: int, body: bytes, content_type: str, headers: Mapping[str, str] | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, status: int, value: object, headers: Mapping[str, str] | None = None) -> None:
        body = json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8")
        self._send(status, body, "application/json; charset=utf-8", headers)

    def _task_service(self) -> TaskService:
        service = getattr(self.server, "task_service", None)
        if service is None:
            raise TaskError(503, "task.unavailable", "asynchronous task service is not enabled")
        return service

    def _post_design(self, path: str, query: str) -> None:
        """Designs are data. Generation and file import never submit solver jobs."""
        from friskoli_cad.standards_export import StandardsExportError
        routes = {"/api/design/generate", "/api/design/export", "/api/design/import", "/api/design/report", "/api/design/evaluate", "/api/design/standards"}
        try:
            maximum = MAX_REQUEST_BYTES if path.endswith("/generate") else MAX_DESIGN_REQUEST_BYTES
            body = strict_json_loads(self._task_body(maximum))
            if path not in routes or query:
                self._json(404, {"error": {"code": "design.not_found", "message": "Unknown design resource"}})
                return
            if not isinstance(body, dict):
                raise ValueError("Design request must be a JSON object")
            if path.endswith("/generate"):
                from friskoli_cad.design import generate_design
                if set(body) != {"project", "settings", "brief"}:
                    raise ValueError("Generation requires project, settings and brief")
                self._json(200, generate_design(body["project"], body["settings"], body["brief"],
                    task_limits=getattr(getattr(self.server, "task_service", None), "limits", None)))
            elif path.endswith("/evaluate"):
                from friskoli_cad.design_evaluation import evaluate_design
                self._json(200, evaluate_design(body))
            elif path.endswith("/standards"):
                from friskoli_cad.standards_export import export_standard_payload
                if not {"payload", "format"} <= set(body) or set(body) - {"payload", "format", "components"} or not isinstance(body["format"], str):
                    raise ValueError("Standards export requires payload, format and optional explicit components")
                if "components" in body and body["components"] is None:
                    raise ValueError("Omit components when absent; explicit components must be a nonempty array")
                output, media, filename = export_standard_payload(body["payload"], body["format"], body.get("components"))
                self._send(200, output, media, {"Content-Disposition": f'attachment; filename="{filename}"'})
            elif path.endswith("/export"):
                from friskoli_cad.design_delivery import export_design_package
                self._send(200, export_design_package(body), "application/zip",
                           {"Content-Disposition": 'attachment; filename="design.friskoli"'})
            elif path.endswith("/import"):
                from friskoli_cad.design_delivery import import_design_package
                if set(body) != {"archive_base64"} or not isinstance(body["archive_base64"], str):
                    raise ValueError("Import requires archive_base64")
                archive = base64.b64decode(body["archive_base64"], validate=True)
                from friskoli_cad.run_delivery import is_task_package, read_task_package
                self._json(200, read_task_package(archive) if is_task_package(archive) else import_design_package(archive))
            else:
                from friskoli_cad.design_delivery import design_report_csv, design_report_html
                if set(body) != {"payload", "format"} or body["format"] not in ("html", "csv"):
                    raise ValueError("Report requires payload and format html or csv")
                render = design_report_html if body["format"] == "html" else design_report_csv
                mime = "text/html" if body["format"] == "html" else "text/csv"
                self._send(200, render(body["payload"]).encode("utf-8"), mime + "; charset=utf-8",
                           {"Content-Disposition": f'attachment; filename="design-report.{body["format"]}"'})
        except StandardsExportError as error:
            response = {"error": {"code": error.code, "message": str(error)}}
            if error.report is not None:
                response["loss_report"] = error.report
            self._json(error.status, response)
        except TaskError as error:
            self._task_error(error)
        except TaskValidationError as error:
            self._json(422, {"issues": error.issues})
        except (ValueError, TypeError, KeyError, binascii.Error) as error:
            self._json(422, {"error": {"code": getattr(error, "code", "design.invalid"), "message": str(error)}})

    def _post_assembly(self, path: str, query: str) -> None:
        try:
            body = strict_json_loads(self._task_body(MAX_REQUEST_BYTES))
            if not isinstance(body, dict) or query:
                raise ValueError("Assembly request must be an object without query parameters")
            from friskoli_cad.biological_assemblies import extract_assembly, apply_assembly, validate_assembly
            if path == "/api/assemblies/extract":
                if set(body) != {"project", "group_id", "metadata"}:
                    raise ValueError("Extraction requires project, group_id and metadata")
                self._json(200, extract_assembly(body["project"], body["group_id"], body["metadata"]))
            elif path == "/api/assemblies/validate":
                if set(body) != {"assembly"}:
                    raise ValueError("Validation requires one assembly")
                validate_assembly(body["assembly"])
                self._json(200, body["assembly"])
            elif path == "/api/assemblies/apply":
                if not {"project", "group_id", "assembly"} <= set(body) or set(body) - {"project", "group_id", "assembly", "bindings"}:
                    raise ValueError("Application requires project, group_id, assembly and optional bindings")
                self._json(200, apply_assembly(body["project"], body["group_id"], body["assembly"], bindings=body.get("bindings")))
            else:
                self._json(404, {"error": {"code": "assembly.not_found", "message": "Unknown assembly resource"}})
        except TaskError as error:
            self._task_error(error)
        except TaskValidationError as error:
            self._json(422, {"issues": error.issues})
        except (ValueError, TypeError, KeyError) as error:
            self._json(422, {"error": {"code": getattr(error, "code", "assembly.invalid"), "message": str(error)}})

    def _task_error(self, error: TaskError) -> None:
        headers = {"Retry-After": "1"} if error.status in (429, 503) else None
        self._json(error.status, error.to_dict(), headers)

    def _task_body(self, maximum: int) -> bytes:
        if self.headers.get("Transfer-Encoding") is not None:
            raise TaskError(400, "task.request_invalid", "a single Content-Length is required")
        lengths = self.headers.get_all("Content-Length", [])
        if len(lengths) != 1 or not re.fullmatch(r"[0-9]{1,18}", lengths[0]):
            raise TaskError(400, "task.request_invalid", "a single integer Content-Length is required")
        length = int(lengths[0])
        if length < 1 or length > maximum:
            raise TaskError(413, "task.resource_limit", "request bytes exceed the published input limit")
        self.connection.settimeout(10)
        try:
            body = self.rfile.read(length)
        except (socket.timeout, OSError) as error:
            raise TaskError(400, "task.request_invalid", "request body was not received completely") from error
        if len(body) != length:
            raise TaskError(400, "task.request_invalid", "request body was not received completely")
        if self.headers.get_content_type() != "application/json":
            raise TaskError(415, "task.content_type", "Content-Type must be application/json")
        return body

    def _get_task(self, path: str, query: str) -> None:
        try:
            service = self._task_service()
            match = re.fullmatch(r"/api/runs/([A-Za-z0-9_-]{1,128})(?:/(input|events|result|export|package|chunks/([A-Za-z0-9_-]{1,128})|artifacts/([A-Za-z0-9_-]{1,128})|checkpoint))?", path)
            if match is None:
                raise TaskError(404, "task.not_found", "unknown task resource")
            run_id, resource, chunk_id, artifact_id = match.groups()
            if resource == "events":
                try:
                    params = parse_qs(query, keep_blank_values=True, strict_parsing=True) if query else {}
                except ValueError as error:
                    raise TaskError(400, "task.cursor_invalid", "invalid event query") from error
                if set(params) - {"after", "limit"} or any(len(values) != 1 for values in params.values()):
                    raise TaskError(400, "task.cursor_invalid", "event query accepts one after and one limit")
                if any(not re.fullmatch(r"[0-9]{1,16}", values[0]) for values in params.values()):
                    raise TaskError(400, "task.cursor_invalid", "event cursors and limits must be non-negative integers")
                page_size = service.capabilities()["limits"]["event_page_size"]
                result = service.events(run_id, after=int(params.get("after", ["0"])[0]),
                                        limit=int(params.get("limit", [str(page_size)])[0]))
            elif resource == 'result' and query:
                params = parse_qs(query,keep_blank_values=True)
                if set(params)-{'offset','limit'} or any(len(v)!=1 or not re.fullmatch(r'[0-9]{1,10}',v[0]) for v in params.values()):
                    raise TaskError(400,'task.manifest_cursor','Invalid manifest offset/limit')
                result = service.manifest(run_id,offset=int(params.get('offset',['0'])[0]),limit=int(params.get('limit',['1024'])[0]))
            elif query:
                raise TaskError(400, "task.request_invalid", "this resource does not accept query parameters")
            elif resource is None:
                result = service.get(run_id)
            elif resource == "input":
                result = service.input(run_id)
            elif resource == "result":
                result = service.manifest(run_id)
            elif resource == 'export':
                from friskoli_cad.run_delivery import collect_task_export
                result = collect_task_export(service, run_id, inline_arrays=True)
            elif resource == 'package':
                from friskoli_cad.run_delivery import export_task_package
                self._send(200, export_task_package(service, run_id), 'application/zip',
                    {'Content-Disposition': f'attachment; filename="{run_id}.friskoli"'})
                return
            elif artifact_id is not None or resource == "checkpoint":
                artifact_id = "checkpoint" if resource == "checkpoint" else artifact_id
                artifact_path, metadata = service.artifact(run_id, artifact_id)
                with artifact_path.open("rb") as stream:
                    self.send_response(200)
                    self.send_header("Content-Type", metadata["media_type"])
                    self.send_header("Content-Length", str(metadata["bytes"]))
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("Content-Disposition", 'attachment; filename="' + (metadata.get('filename') or 'final-fields.npz') + '"')
                    self.send_header("ETag", '"' + metadata["sha256"] + '"')
                    self.end_headers()
                    for block in iter(lambda: stream.read(1024 * 1024), b""):
                        self.wfile.write(block)
                return
            else:
                self._send(200, service.chunk(run_id, chunk_id), "application/json; charset=utf-8")
                return
            self._json(200, result)
        except TaskError as error:
            self._task_error(error)

    def _post_task(self, path: str, query: str) -> None:
        try:
            service = self._task_service()
            if query:
                raise TaskError(400, "task.request_invalid", "task mutations do not accept query parameters")
            if path == '/api/runs/checkpoint-import':
                import uuid
                from friskoli_cad.engine.task_checkpoint import load_task_checkpoint
                if self.headers.get('Transfer-Encoding'):
                    raise TaskError(400, 'task.request_invalid', 'Checkpoint upload requires Content-Length.')
                try:
                    length = int(self.headers.get('Content-Length', '-1'))
                except ValueError:
                    length = -1
                if not 0 < length <= service.limits.estimated_memory_bytes:
                    raise TaskError(413, 'task.resource_limit', 'Checkpoint upload exceeds its byte budget.')
                self.connection.settimeout(10)
                folder = service.directory / 'imports'
                folder.mkdir(exist_ok=True)
                if len(list(folder.glob('*.zip'))) >= service.limits.queued_runs * 2:
                    raise TaskError(429, 'task.import_limit', 'Import staging limit reached.')
                identifier = 'import_' + uuid.uuid4().hex
                destination = folder / (identifier + '.zip')
                remaining = length
                try:
                    with destination.open('xb') as outgoing:
                        while remaining:
                            block = self.rfile.read(min(1024 * 1024, remaining))
                            if not block:
                                raise ValueError('Incomplete checkpoint upload')
                            outgoing.write(block)
                            remaining -= len(block)
                    sim = load_task_checkpoint(destination, maximum=service.limits.estimated_memory_bytes)
                    self._json(201, {'checkpoint_id':identifier, 'project':sim.project,
                        'step_index':sim.frame_index, 'time_s':sim.time_s, 'seed':sim.seed})
                except (ValueError, OSError) as error:
                    destination.unlink(missing_ok=True)
                    raise TaskError(422, 'task.checkpoint_invalid', str(error)) from error
                return
            if path == '/api/runs/from-checkpoint':
                request = strict_json_loads(self._task_body(service.limits.request_bytes))
                if type(request) is not dict or set(request) != {'checkpoint_id','submission'} or not re.fullmatch(r'import_[a-f0-9]{32}', str(request.get('checkpoint_id'))):
                    raise TaskError(422, 'task.import_request', 'Import needs a staged checkpoint_id and submission.')
                source = service.directory / 'imports' / (request['checkpoint_id'] + '.zip')
                task, created = service.import_checkpoint(source, request['submission'], self.headers.get('Idempotency-Key'))
                self._json(202 if created else 200, task)
                return
            if path == "/api/runs/preflight":
                self._json(200, service.preflight(self._task_body(service.limits.request_bytes)))
                return
            if path == "/api/runs":
                keys = self.headers.get_all("Idempotency-Key", [])
                if len(keys) != 1 or not keys[0].strip():
                    raise TaskError(400, "task.idempotency_key", "a single nonempty Idempotency-Key is required")
                maximum = service.capabilities()["limits"]["request_bytes"]
                try:
                    submission = strict_json_loads(self._task_body(maximum))
                except TaskValidationError as error:
                    self._json(400, {"task_contract_version": "0.1.0", "issues": error.issues})
                    return
                task, created = service.submit(submission, keys[0])
                self._json(202 if created else 200, task, {"Location": f"/api/runs/{task['run_id']}"})
                return
            match = re.fullmatch(r"/api/runs/([A-Za-z0-9_-]+)/(cancel|pause|resume|migration-preview|migrate)", path)
            if match is None:
                raise TaskError(404, "task.not_found", "unknown task resource")
            action = match.group(2)
            if action in ('resume','migration-preview','migrate'):
                request = strict_json_loads(self._task_body(service.limits.request_bytes))
                if action == 'resume':
                    task, created = service.resume(match.group(1), request, self.headers.get('Idempotency-Key'))
                    self._json(202 if created else 200, task)
                else:
                    self._json(200, service.migrate(match.group(1), request, self.headers.get('Idempotency-Key'), preview=action=='migration-preview'))
                return
            if self.headers.get("Transfer-Encoding") or self.headers.get("Content-Length", "0") != "0":
                raise TaskError(400, "task.request_invalid", "cancel does not accept a request body")
            task, accepted = (service.pause if action == 'pause' else service.cancel)(match.group(1))
            self._json(202 if accepted else 200, task)
        except TaskValidationError as error:
            self._json(422, {"task_contract_version": "0.1.0", "issues": error.issues})
        except TaskError as error:
            self._task_error(error)

    def _packages(self, path, *, mutate=False):
        from friskoli_cad.packages import PackageStore, inspect_package, MAX_ARCHIVE
        import base64
        try:
            store = PackageStore.default()
            if not mutate and path == '/api/packages':
                self._json(200, {'packages':store.list()})
                return
            request = strict_json_loads(self._task_body((MAX_ARCHIVE * 4 // 3) + 65536))
            if type(request) is not dict:
                raise ValueError('Package request must be an object')
            if path in ('/api/packages/preview','/api/packages/install'):
                data = base64.b64decode(request['archive_base64'], validate=True)
                if len(data) > MAX_ARCHIVE:
                    raise ValueError('Package archive exceeds 32 MiB')
                result = inspect_package(data)[0] if path.endswith('/preview') else store.install(data, expected_sha256=request['expected_sha256'])
            elif path == '/api/packages/resolve':
                result = store.resolve(request['requirements'], pin_id=request.get('pin_id'))
            elif path == '/api/packages/uninstall':
                result = store.uninstall(request['id'], request['version'])
            elif path == '/api/packages/file':
                if set(request) != {'id','version','path','expected_sha256'}:
                    raise ValueError('Package file requires id, version, path and expected_sha256')
                data = store.read_file(request['id'], request['version'], request['path'], expected_sha256=request['expected_sha256'])
                if len(data) > 64 * 1024 * 1024:
                    raise TaskError(413,'package.file_limit','Package file exceeds 64 MiB')
                self._send(200,data,'application/octet-stream',{'Content-Disposition':'attachment; filename="package-file.bin"','X-Content-Type-Options':'nosniff'})
                return
            else:
                raise TaskError(404,'package.not_found','Unknown package operation')
            self._json(200, result)
        except TaskError as error:
            self._task_error(error)
        except (ValueError, KeyError, TypeError, ProtocolError) as error:
            self._json(422, {'issues':[{'code':getattr(error,'code','package.invalid'), 'severity':'error',
                'phase':'validate','path':getattr(error,'path','/package'),'targets':[],'message':str(error)}]})

    def do_GET(self) -> None:  # noqa: N802 - stdlib handler API
        target = urlsplit(self.path)
        path = target.path
        if path == "/api/packages":
            self._packages(path)
            return
        if path == "/api/runs" or path.startswith("/api/runs/"):
            self._get_task(path, target.query)
            return
        if path == "/api/example-project":
            self._send(200, EXAMPLE_PROJECT.read_bytes(), "application/json; charset=utf-8")
        elif path.startswith('/api/examples/'):
            from friskoli_cad.engine.presets import make_example
            try:
                self._json(200, make_example(path.rsplit('/', 1)[-1]))
            except ValueError:
                self._json(404, {'error': {'code': 'example.not_found', 'message': 'Unknown first-release example'}})
        elif path == "/api/catalog":
            try:
                query = parse_qs(target.query, keep_blank_values=True, strict_parsing=True) if target.query else {}
            except ValueError:
                query = {"invalid": []}
            profile = query.get("execution_profile", [MODULAR_PROFILE])
            if set(query) - {"execution_profile"} or len(profile) != 1 or profile[0] != MODULAR_PROFILE:
                self._json(422, {"error": {"code": "catalog.profile", "path": "/execution_profile", "message": "Unsupported execution profile"}})
                return
            self._json(200, registry_for_profile(profile[0]).catalog)
        elif path == "/api/capabilities":
            from friskoli_cad.standards_export import standards_capabilities
            catalog = modular_registry().catalog
            capabilities = {
                'api_version': '0.2.0', 'workspace_versions': ['0.7.0'],
                'catalog_versions': ['0.5.0'], 'execution_semantics': MODULAR_PROFILE,
                'execution_profiles': [MODULAR_PROFILE], 'project_versions': ['0.6.0'], 'replay_versions': ['0.1.0'],
                'design': {'design_version': '0.3.0', 'design_versions': ['0.1.0', '0.2.0', '0.3.0'],
                    'evaluation_version': '0.1.0', 'package_version': '0.1.0', 'execution_profiles': [MODULAR_PROFILE],
                    'max_runs': 32, 'request_bytes': MAX_DESIGN_REQUEST_BYTES, 'standards': standards_capabilities()},
                'biological_assemblies': {'assembly_versions': ['0.1.0'], 'extract': True, 'apply': True},
                'execution': {'mode': 'synchronous', 'pause': False, 'resume': False, 'partial_results': False},
                'limits': {'request_bytes': MAX_REQUEST_BYTES, 'cells': MAX_VIEW_CELLS, 'xy_tiles': MAX_VIEW_TILES,
                    'replay_values': MAX_REPLAY_VALUES, 'steps': MAX_STEPS, 'replay_cell_frames': MAX_REPLAY_CELL_FRAMES, 'replay_bytes': MAX_REPLAY_BYTES},
                'placeables': [{'kind': item['kind'], 'module': item['initializer']['module']} for item in catalog['objects']],
                'placeable_profiles': {MODULAR_PROFILE: [item['initializer']['module'] for item in catalog['objects']]},
            }
            service = getattr(self.server, 'task_service', None)
            if service is not None:
                task_capabilities = service.capabilities()
                capabilities.update(task_preflight={'href': '/api/runs/preflight', 'method': 'POST'}, task=task_capabilities,
                    task_longrun_profiles={MODULAR_PROFILE: task_capabilities}, task_profiles={MODULAR_PROFILE: task_capabilities})
            self._json(200, capabilities)
        elif path == "/api/assemblies":
            from friskoli_cad.assembly_library import official_assemblies
            self._json(200, {"library_version": "0.1.0", "assemblies": official_assemblies()})
        elif path in STATIC_FILES:
            filename, content_type = STATIC_FILES[path]
            body = files("friskoli_cad").joinpath("web", filename).read_bytes()
            self._send(200, body, content_type)
        else:
            self._json(404, {"error": {"code": "http.not_found", "message": "unknown path"}})

    def do_POST(self) -> None:  # noqa: N802 - stdlib handler API
        target = urlsplit(self.path)
        if target.path in ('/api/catalog/project','/api/diagnostics'):
            try:
                from friskoli_cad.engine.profiles import registry_for_project
                from friskoli_cad.diagnostics import diagnose_project
                request = strict_json_loads(self._task_body(MAX_REQUEST_BYTES))
                if type(request) is not dict or set(request) != {'project'}:
                    raise ValueError('Request needs exactly one project')
                registry = registry_for_project(request['project'])
                self._json(200, {'catalog':registry.catalog,'version_lock':self._task_service().version_lock(request['project'])}
                    if target.path == '/api/catalog/project' else diagnose_project(request['project'],registry=registry))
            except TaskError as error:
                self._task_error(error)
            except (ValueError,TypeError,KeyError,ProtocolError) as error:
                self._json(422,{'issues':[{'code':getattr(error,'code','request.invalid'),'message':str(error)}]})
            return
        if target.path.startswith("/api/assemblies/"):
            self._post_assembly(target.path, target.query)
            return
        if target.path.startswith("/api/design/"):
            self._post_design(target.path, target.query)
            return
        if target.path.startswith("/api/packages/"):
            self._packages(target.path, mutate=True)
            return
        if target.path == "/api/runs" or target.path.startswith("/api/runs/"):
            self._post_task(target.path, target.query)
            return
        if self.path not in ("/api/replay", "/api/validate"):
            self._json(404, {"error": {"code": "http.not_found", "message": "unknown path"}})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > MAX_REQUEST_BYTES:
                raise ReplayRequestError("request.size", "request size must be between 1 and 1000000 bytes", 413)
            request = json.loads(self.rfile.read(length))
            if not isinstance(request, dict) or not {"project", "dt_s", "steps"} <= set(request) or set(request) - {"project", "dt_s", "steps", "request_id"}:
                raise ReplayRequestError("request.shape", "expected project, dt_s and steps")
            request_id = request.get("request_id")
            if request_id is not None and (not isinstance(request_id, str) or not 1 <= len(request_id) <= 128):
                raise ReplayRequestError("request.id", "request_id must be a short string")
            if self.path == "/api/validate":
                simulation = prepare_project(request["project"], dt_s=request["dt_s"], steps=request["steps"],
                                             validation_only=getattr(self.server, "task_service", None) is not None)
                self._json(200, {"api_version": "0.2.0", "valid": True, "issues": [],
                                 "cells": len(simulation.current.cell_frame["cells"]),
                                 "voxels": simulation.current.domain.voxel_count})
                return
            replay = build_replay(request["project"], dt_s=request["dt_s"], steps=request["steps"])
            replay["execution"] = {"api_version": "0.2.0", "request_id": request_id, "status": "completed",
                                   "dt_s": request["dt_s"], "steps": request["steps"],
                                   "project_sha256": hashlib.sha256(json.dumps(request["project"], sort_keys=True,
                                       separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()).hexdigest()}
            self._json(200, replay)
        except (ReplayRequestError, ProtocolError, SimulationError, ValueError, TypeError, KeyError) as error:
            status = error.status if isinstance(error, ReplayRequestError) else 422
            code = getattr(error, "code", "request.invalid")
            self._json(status, {"error": {"code": code, "path": getattr(error, "path", "/"), "message": str(error)}})


def default_task_directory() -> Path:
    """Keep durable local runs outside source checkouts."""
    if os.name == "nt":
        root = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    else:
        root = Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local" / "state"))
    return root / "Friskoli-CAD" / "tasks"


class ReplayServer(ThreadingHTTPServer):
    """Local HTTP transport owns and closes its optional task service."""

    def __init__(self, address, *, task_directory: str | Path | None = None, task_limits=None):
        super().__init__(address, ReplayHandler)
        self.task_service = None
        if task_directory is not None:
            try:
                self.task_service = TaskService(task_directory, limits=task_limits)
            except BaseException:
                super().server_close()
                raise

    def server_close(self) -> None:
        try:
            super().server_close()
        finally:
            if self.task_service is not None:
                self.task_service.close()


def _positive_seconds(value: str) -> int:
    try:
        seconds = int(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError("must be a positive integer number of seconds") from error
    if seconds < 1:
        raise argparse.ArgumentTypeError("must be a positive integer number of seconds")
    return seconds


def main() -> None:
    parser = argparse.ArgumentParser(description="Serve the local Friskoli-CAD replay viewer")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--task-dir", type=Path, default=default_task_directory(),
                        help="persistent task database and result directory (outside the repository by default)")
    parser.add_argument("--sync-only", action="store_true", help="serve only the bounded synchronous API")
    parser.add_argument("--task-wall-time-s", type=_positive_seconds, default=1800,
                        help="asynchronous task wall-time limit in seconds (default: 1800; ignored with --sync-only)")
    parser.add_argument("--task-voxels", type=_positive_seconds, default=262144,
                        help="maximum computation voxels per task (default: 262144)")
    parser.add_argument("--task-memory-mib", type=_positive_seconds, default=512,
                        help="estimated/actual worker RAM limit in MiB (default: 512)")
    parser.add_argument("--task-output-mib", type=_positive_seconds, default=128,
                        help="total JSON and final field artifact budget in MiB (default: 128)")
    parser.add_argument("--task-chunk-mib", type=_positive_seconds, default=4,
                        help="single JSON frame budget in MiB (default: 4)")
    arguments = parser.parse_args()
    server = ReplayServer(("127.0.0.1", arguments.port),
                          task_directory=None if arguments.sync_only else arguments.task_dir,
                          task_limits=None if arguments.sync_only else TaskLimits(wall_time_s=arguments.task_wall_time_s,
                              voxels=arguments.task_voxels, estimated_memory_bytes=arguments.task_memory_mib * 1024 * 1024,
                              output_bytes=arguments.task_output_mib * 1024 * 1024, chunk_bytes=arguments.task_chunk_mib * 1024 * 1024))
    print(f"Friskoli-CAD replay: http://127.0.0.1:{server.server_port}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
